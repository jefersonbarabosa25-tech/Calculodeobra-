# CalculaObra 3.0 — gerar APK pelo celular

Este projeto foi preparado para você colocar no GitHub e gerar o APK automaticamente pelo GitHub Actions, sem precisar instalar Android Studio no celular.

## Como usar pelo celular

1. Abra seu repositório no GitHub.
2. Entre em **Code > Upload files**.
3. Envie TODOS os arquivos e pastas deste projeto, mantendo os caminhos:
   - `.github/workflows/build-apk.yml`
   - `app/...`
   - `build.gradle.kts`
   - `settings.gradle.kts`
   - `gradle.properties`
4. Faça o commit na branch **principal**.
5. No GitHub, abra **Actions**.
6. Toque em **Gerar APK - CalculaObra**.
7. Se aparecer, toque em **Run workflow**.
8. Espere o processo terminar com um ✓ verde.
9. Abra a execução concluída e procure **Artifacts**.
10. Baixe **CalculaObra-APK**.
11. Extraia o arquivo baixado e instale `app-debug.apk` no Android.

## Importante

O arquivo `.github/workflows/build-apk.yml` é o responsável por mandar o GitHub construir o APK.

O aplicativo é uma ferramenta de estimativas para planejamento/orçamento. Cálculos estruturais de laje, pilares, vigas e fundações devem ser definidos e conferidos por engenheiro ou arquiteto habilitado.

## Se você já tem um repositório CalculaObra

Não precisa criar outro repositório. Você pode copiar os arquivos deste projeto para o seu repositório atual. O workflow já aceita as branches `principal` e `main`.

## Nome do aplicativo

CalculaObra

## Identificador

br.com.calculaoobra.app
