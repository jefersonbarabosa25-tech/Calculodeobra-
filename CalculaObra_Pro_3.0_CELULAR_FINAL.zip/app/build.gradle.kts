plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="br.com.calculaoobra.app"; compileSdk=35
 defaultConfig { applicationId="br.com.calculaoobra.app"; minSdk=23; targetSdk=35; versionCode=3; versionName="3.0" } }
dependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.appcompat:appcompat:1.7.0"); implementation("androidx.activity:activity-ktx:1.10.1") }