# CalculaObra Pro 3.0
Versão de protótipo avançado para medições, estimativas, orçamento e organização de obras.
Inclui projetos salvos localmente, preços editáveis, materiais, laje geométrica, piso, pintura, telhado, relatório e gastos.
Os cálculos são estimativas de planejamento. Dimensionamento estrutural deve ser feito por profissional habilitado.

## APK pelo celular
Envie o conteúdo ao GitHub, abra Actions e execute "Gerar APK - CalculaObra". Baixe o artefato CalculaObra-debug-apk.